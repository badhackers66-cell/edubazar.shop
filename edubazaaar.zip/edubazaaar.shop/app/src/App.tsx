import { useState, useEffect, useCallback } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { Header, Footer } from '@/components/layout';
import { AuthModal, Toast, Chatbot } from '@/components/ui-custom';
import { Home, Courses, Books, Cart, Account, Dashboard, Support } from '@/pages';
import { useAuth, useCart, usePurchases, useToast } from '@/hooks';
import type { Course, Book } from '@/types';
import { CONFIG } from '@/data';
import './App.css';

// Declare Razorpay for TypeScript
declare global {
  interface Window {
    Razorpay: any;
  }
}

function App() {
  const navigate = useNavigate();
  const { user, login, register, logout } = useAuth();
  const { cart, totalItems, subtotal, total, discount, addCourse, addBook, removeItem, clearCart, isInCart } = useCart();
  const { purchases, totalSpent, hasAnyPurchase, addPurchase, hasPurchased } = usePurchases();
  const { toasts, showToast, removeToast } = useToast();
  
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Load Razorpay script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  // Handle add course to cart
  const handleAddCourse = useCallback((course: Course) => {
    if (isInCart(course.id)) {
      showToast('Already in cart!', 'error');
      return;
    }
    if (hasPurchased(course.id)) {
      showToast('Already purchased!', 'error');
      return;
    }
    addCourse(course);
    showToast(`${course.title.substring(0, 30)}... added to cart! 🛒`, 'success');
  }, [addCourse, isInCart, hasPurchased, showToast]);

  // Handle add book to cart
  const handleAddBook = useCallback((book: Book) => {
    if (isInCart(book.id)) {
      showToast('Already in cart!', 'error');
      return;
    }
    if (hasPurchased(book.id)) {
      showToast('Already purchased!', 'error');
      return;
    }
    addBook(book);
    showToast(`${book.title.substring(0, 30)}... added to cart! 🛒`, 'success');
  }, [addBook, isInCart, hasPurchased, showToast]);

  // Handle checkout
  const handleCheckout = useCallback(() => {
    if (cart.length === 0) {
      showToast('Cart is empty!', 'error');
      return;
    }

    const options = {
      key: CONFIG.razorpayKey,
      amount: total * 100,
      currency: 'INR',
      name: 'edubazar.shop',
      description: `${cart.length} Item(s)`,
      handler: function(response: any) {
        addPurchase(response.razorpay_payment_id, cart);
        clearCart();
        showToast('Purchase successful! 🎉 Check My Courses.', 'success');
        navigate('/account');
      },
      prefill: {
        email: user?.email || CONFIG.email,
      },
      theme: {
        color: '#00c896',
      },
    };

    if (window.Razorpay) {
      const rzp = new window.Razorpay(options);
      rzp.open();
    } else {
      showToast('Payment system loading. Please try again.', 'error');
    }
  }, [cart, total, user, addPurchase, clearCart, showToast, navigate]);

  // Unified add to cart handler
  const handleAddToCart = useCallback((item: Course | Book) => {
    if ('duration' in item) {
      handleAddCourse(item);
    } else {
      handleAddBook(item);
    }
  }, [handleAddCourse, handleAddBook]);

  return (
    <div className="min-h-screen bg-[#0d1117]">
      {/* Header */}
      <Header 
        user={user}
        cartCount={totalItems}
        hasPurchases={hasAnyPurchase}
        onLoginClick={() => setIsAuthModalOpen(true)}
        onLogout={logout}
      />

      {/* Main Content */}
      <main className="min-h-screen">
        <Routes>
          <Route 
            path="/" 
            element={
              <Home 
                onAddToCart={handleAddToCart}
                isInCart={isInCart}
                isPurchased={hasPurchased}
              />
            } 
          />
          <Route 
            path="/courses" 
            element={
              <Courses 
                onAddToCart={handleAddCourse}
                isInCart={isInCart}
                isPurchased={hasPurchased}
              />
            } 
          />
          <Route 
            path="/courses/:category" 
            element={
              <Courses 
                onAddToCart={handleAddCourse}
                isInCart={isInCart}
                isPurchased={hasPurchased}
              />
            } 
          />
          <Route 
            path="/courses/:category/:subcategory" 
            element={
              <Courses 
                onAddToCart={handleAddCourse}
                isInCart={isInCart}
                isPurchased={hasPurchased}
              />
            } 
          />
          <Route 
            path="/books" 
            element={
              <Books 
                onAddToCart={handleAddBook}
                isInCart={isInCart}
                isPurchased={hasPurchased}
              />
            } 
          />
          <Route 
            path="/books/:category" 
            element={
              <Books 
                onAddToCart={handleAddBook}
                isInCart={isInCart}
                isPurchased={hasPurchased}
              />
            } 
          />
          <Route 
            path="/cart" 
            element={
              <Cart 
                cart={cart}
                subtotal={subtotal}
                total={total}
                discount={discount}
                onRemove={removeItem}
                onCheckout={handleCheckout}
                onClear={clearCart}
              />
            } 
          />
          <Route 
            path="/account" 
            element={
              <Account 
                user={user}
                purchases={purchases}
                totalSpent={totalSpent}
                onLoginClick={() => setIsAuthModalOpen(true)}
                onLogout={logout}
              />
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              hasAnyPurchase ? (
                <Dashboard purchases={purchases} />
              ) : (
                <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
                  <div className="text-center">
                    <h1 className="text-2xl font-bold text-white mb-4">Dashboard Access</h1>
                    <p className="text-[#8b949e] mb-6">Purchase a course to unlock your learning dashboard</p>
                    <button 
                      onClick={() => navigate('/courses')}
                      className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117] px-6 py-3 rounded-lg font-semibold"
                    >
                      Browse Courses
                    </button>
                  </div>
                </div>
              )
            } 
          />
          <Route path="/support" element={<Support />} />
        </Routes>
      </main>

      {/* Footer */}
      <Footer />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={login}
        onRegister={register}
      />

      {/* Toast Notifications */}
      <Toast toasts={toasts} onRemove={removeToast} />

      {/* Chatbot */}
      <Chatbot />

      {/* WhatsApp Float */}
      <a
        href={`https://wa.me/${CONFIG.whatsapp}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 left-6 z-50 w-12 h-12 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        title="Chat on WhatsApp"
      >
        <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>
    </div>
  );
}

export default App;
