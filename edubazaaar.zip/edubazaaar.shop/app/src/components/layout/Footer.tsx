import { Link } from 'react-router-dom';
import { 
  Instagram, Youtube, Send, MessageCircle, 
  Mail, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CONFIG } from '@/data';
import { useToast } from '@/hooks';

export function Footer() {
  const { showToast } = useToast();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('Subscribed successfully! Check your email 📧', 'success');
  };

  return (
    <footer className="bg-[#161b22] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 group mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-[#00c896] to-[#00a97e] rounded-lg flex items-center justify-center text-[#0d1117] font-bold text-xl transition-transform group-hover:scale-105">
                E
              </div>
              <div className="flex flex-col">
                <span className="text-white font-bold text-xl leading-tight">
                  <span className="text-[#00c896]">edu</span>bazar
                </span>
                <span className="text-[#8b949e] text-xs leading-tight">.shop</span>
              </div>
            </Link>
            <p className="text-[#8b949e] text-sm leading-relaxed mb-6">
              Premium online learning platform for tech, trading, and business professionals. 
              Empowering careers since 2023.
            </p>
            <div className="flex gap-3">
              <a 
                href="#" 
                className="w-10 h-10 bg-[#21262d] rounded-lg flex items-center justify-center text-[#8b949e] hover:text-[#00c896] hover:bg-[#00c896]/10 transition-all border border-white/5"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-[#21262d] rounded-lg flex items-center justify-center text-[#8b949e] hover:text-[#f85149] hover:bg-[#f85149]/10 transition-all border border-white/5"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-[#21262d] rounded-lg flex items-center justify-center text-[#8b949e] hover:text-[#58a6ff] hover:bg-[#58a6ff]/10 transition-all border border-white/5"
              >
                <Send className="w-5 h-5" />
              </a>
              <a 
                href={`https://wa.me/${CONFIG.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-[#21262d] rounded-lg flex items-center justify-center text-[#8b949e] hover:text-[#25D366] hover:bg-[#25D366]/10 transition-all border border-white/5"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-3">
              <li>
                <Link to="/courses" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  All Courses
                </Link>
              </li>
              <li>
                <Link to="/books" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Books
                </Link>
              </li>
              <li>
                <Link to="/courses/hacking" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Ethical Hacking
                </Link>
              </li>
              <li>
                <Link to="/courses/programming" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Programming
                </Link>
              </li>
              <li>
                <Link to="/courses/trading" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Trading & Finance
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Company
            </h4>
            <ul className="space-y-3">
              <li>
                <Link to="/support" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
                  Refund Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Contact
            </h4>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-3 text-[#8b949e] text-sm">
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                +91 97591 31256
              </li>
              <li className="flex items-center gap-3 text-[#8b949e] text-sm">
                <Mail className="w-4 h-4 text-[#00c896]" />
                {CONFIG.email}
              </li>
              <li className="flex items-center gap-3 text-[#8b949e] text-sm">
                <Clock className="w-4 h-4 text-[#58a6ff]" />
                Mon–Sat, 9 AM – 9 PM IST
              </li>
            </ul>

            <div className="bg-[#21262d] rounded-xl p-4 border border-white/5">
              <h5 className="text-white font-medium mb-2 text-sm">Stay Updated</h5>
              <p className="text-[#8b949e] text-xs mb-3">Get course offers and updates.</p>
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <Input 
                  type="email"
                  placeholder="Your email"
                  className="flex-1 bg-[#0d1117] border-white/10 text-white text-sm placeholder:text-[#8b949e]/50"
                />
                <Button type="submit" size="sm" className="bg-[#00c896] text-[#0d1117] hover:bg-[#00a97e]">
                  Go
                </Button>
              </form>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[#8b949e] text-sm">
            © {new Date().getFullYear()} {CONFIG.brandName}. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
              Privacy
            </a>
            <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
              Terms
            </a>
            <a href="#" className="text-[#8b949e] hover:text-[#00c896] text-sm transition-colors">
              Refund Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
