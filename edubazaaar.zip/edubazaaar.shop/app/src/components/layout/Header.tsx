import { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Menu, X, ShoppingCart, User, ChevronDown, BookOpen, 
  Shield, Code, TrendingUp, Briefcase, Brain, Home, 
  GraduationCap, BarChart3, HeadphonesIcon, LogOut
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { categoriesData, bookCategories } from '@/data';
import type { User as UserType } from '@/types';

interface HeaderProps {
  user: UserType | null;
  cartCount: number;
  hasPurchases: boolean;
  onLoginClick: () => void;
  onLogout: () => void;
}

const categoryIcons: Record<string, React.ElementType> = {
  hacking: Shield,
  programming: Code,
  trading: TrendingUp,
  business: Briefcase,
  ai: Brain,
};

export function Header({ user, cartCount, hasPurchases, onLoginClick, onLogout }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const categoriesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  const isActive = (path: string) => location.pathname === path;

  const scrollCategories = (direction: 'left' | 'right') => {
    if (categoriesRef.current) {
      const scrollAmount = 200;
      categoriesRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <header 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-[#0d1117]/95 backdrop-blur-xl shadow-lg' 
            : 'bg-[#0d1117]/80 backdrop-blur-md'
        }`}
      >
        {/* Main Header */}
        <div className="border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Logo - Click goes to Home */}
              <Link to="/" className="flex items-center gap-2 group flex-shrink-0" onClick={() => navigate('/')}>
                <div className="w-9 h-9 bg-gradient-to-br from-[#00c896] to-[#00a97e] rounded-lg flex items-center justify-center text-[#0d1117] font-bold text-lg transition-transform group-hover:scale-105">
                  E
                </div>
                <div className="flex flex-col">
                  <span className="text-white font-bold text-lg leading-tight">
                    <span className="text-[#00c896]">edu</span>bazar
                  </span>
                  <span className="text-[#8b949e] text-[10px] leading-tight">.shop</span>
                </div>
              </Link>

              {/* Desktop Navigation */}
              <nav className="hidden lg:flex items-center gap-1">
                <Link to="/">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className={`gap-2 ${isActive('/') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#8b949e] hover:text-white hover:bg-white/5'}`}
                  >
                    <Home className="w-4 h-4" />
                    Home
                  </Button>
                </Link>

                {/* Courses Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className={`gap-2 ${location.pathname.includes('/courses') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#8b949e] hover:text-white hover:bg-white/5'}`}
                    >
                      <GraduationCap className="w-4 h-4" />
                      Courses
                      <ChevronDown className="w-3 h-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent 
                    align="start" 
                    className="w-64 bg-[#161b22] border-white/10 p-2"
                  >
                    {categoriesData.map((cat) => {
                      const Icon = categoryIcons[cat.id] || Code;
                      return (
                        <DropdownMenuItem 
                          key={cat.id}
                          onClick={() => navigate(`/courses/${cat.id}`)}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/5 focus:bg-white/5"
                        >
                          <div 
                            className="w-8 h-8 rounded-lg flex items-center justify-center"
                            style={{ background: `var(--${cat.color})20`, color: `var(--${cat.color})` }}
                          >
                            <Icon className="w-4 h-4" />
                          </div>
                          <span className="text-sm text-[#e6edf3]">{cat.name}</span>
                        </DropdownMenuItem>
                      );
                    })}
                    <DropdownMenuSeparator className="bg-white/10" />
                    <DropdownMenuItem 
                      onClick={() => navigate('/courses')}
                      className="flex items-center justify-between px-3 py-2.5 rounded-lg cursor-pointer text-[#00c896] hover:bg-[#00c896]/10 focus:bg-[#00c896]/10"
                    >
                      <span className="text-sm font-medium">View All Courses</span>
                      <TrendingUp className="w-4 h-4" />
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Books Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className={`gap-2 ${location.pathname.includes('/books') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#8b949e] hover:text-white hover:bg-white/5'}`}
                    >
                      <BookOpen className="w-4 h-4" />
                      Books
                      <ChevronDown className="w-3 h-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent 
                    align="start" 
                    className="w-64 bg-[#161b22] border-white/10 p-2"
                  >
                    {bookCategories.map((cat) => {
                      const Icon = categoryIcons[cat.color] || BookOpen;
                      return (
                        <DropdownMenuItem 
                          key={cat.id}
                          onClick={() => navigate(`/books/${cat.id}`)}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/5 focus:bg-white/5"
                        >
                          <div 
                            className="w-8 h-8 rounded-lg flex items-center justify-center"
                            style={{ background: `var(--${cat.color})20`, color: `var(--${cat.color})` }}
                          >
                            <Icon className="w-4 h-4" />
                          </div>
                          <span className="text-sm text-[#e6edf3]">{cat.name}</span>
                        </DropdownMenuItem>
                      );
                    })}
                    <DropdownMenuSeparator className="bg-white/10" />
                    <DropdownMenuItem 
                      onClick={() => navigate('/books')}
                      className="flex items-center justify-between px-3 py-2.5 rounded-lg cursor-pointer text-[#00c896] hover:bg-[#00c896]/10 focus:bg-[#00c896]/10"
                    >
                      <span className="text-sm font-medium">View All Books</span>
                      <BookOpen className="w-4 h-4" />
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Dashboard - Only show if user has purchases */}
                {hasPurchases && (
                  <Link to="/dashboard">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className={`gap-2 ${isActive('/dashboard') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#8b949e] hover:text-white hover:bg-white/5'}`}
                    >
                      <BarChart3 className="w-4 h-4" />
                      Dashboard
                    </Button>
                  </Link>
                )}

                <Link to="/support">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className={`gap-2 ${isActive('/support') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#8b949e] hover:text-white hover:bg-white/5'}`}
                  >
                    <HeadphonesIcon className="w-4 h-4" />
                    Support
                  </Button>
                </Link>
              </nav>

              {/* Right Actions */}
              <div className="flex items-center gap-2">
                {/* Cart */}
                <Link to="/cart">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="relative text-[#8b949e] hover:text-white hover:bg-white/5"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {cartCount > 0 && (
                      <Badge 
                        className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-[#f85149] text-white text-xs border-2 border-[#0d1117]"
                      >
                        {cartCount}
                      </Badge>
                    )}
                  </Button>
                </Link>

                {/* User */}
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="gap-2 text-[#00c896] border border-[#00c896]/30 hover:bg-[#00c896]/10"
                      >
                        <div className="w-6 h-6 bg-[#00c896] rounded-full flex items-center justify-center text-[#0d1117] text-xs font-bold">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <span className="hidden sm:inline">{user.name.split(' ')[0]}</span>
                        <ChevronDown className="w-3 h-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-[#161b22] border-white/10">
                      <DropdownMenuItem onClick={() => navigate('/account')} className="cursor-pointer hover:bg-white/5">
                        <User className="w-4 h-4 mr-2" />
                        My Account
                      </DropdownMenuItem>
                      {hasPurchases && (
                        <DropdownMenuItem onClick={() => navigate('/dashboard')} className="cursor-pointer hover:bg-white/5">
                          <BarChart3 className="w-4 h-4 mr-2" />
                          Dashboard
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator className="bg-white/10" />
                      <DropdownMenuItem onClick={onLogout} className="cursor-pointer text-[#f85149] hover:bg-[#f85149]/10 focus:bg-[#f85149]/10">
                        <LogOut className="w-4 h-4 mr-2" />
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={onLoginClick}
                      className="hidden sm:flex gap-2 text-[#8b949e] hover:text-white hover:bg-white/5"
                    >
                      <User className="w-4 h-4" />
                      Login
                    </Button>
                    <Button 
                      size="sm"
                      onClick={onLoginClick}
                      className="hidden md:flex gap-2 bg-[#00c896] text-[#0d1117] hover:bg-[#00a97e]"
                    >
                      <User className="w-4 h-4" />
                      Sign Up
                    </Button>
                  </>
                )}

                {/* Mobile Menu Toggle */}
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="lg:hidden text-[#8b949e] hover:text-white hover:bg-white/5"
                >
                  {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Categories Bar - Desktop */}
        <div className="hidden lg:block border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center h-12">
              <button 
                onClick={() => scrollCategories('left')}
                className="p-1 text-[#8b949e] hover:text-white transition-colors"
              >
                <ChevronDown className="w-4 h-4 rotate-90" />
              </button>
              
              <div 
                ref={categoriesRef}
                className="flex-1 flex items-center gap-1 overflow-x-auto hide-scrollbar px-2"
              >
                <span className="text-xs text-[#8b949e] uppercase tracking-wider font-medium mr-2 flex-shrink-0">
                  Browse:
                </span>
                
                {/* Home Button in Categories Bar */}
                <button 
                  onClick={() => navigate('/')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all whitespace-nowrap flex-shrink-0 ${
                    isActive('/') 
                      ? 'text-[#00c896] bg-[#00c896]/10' 
                      : 'text-[#8b949e] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Home className="w-3.5 h-3.5" />
                  Home
                </button>

                <div className="w-px h-4 bg-white/10" />
                
                {categoriesData.map((cat) => {
                  const Icon = categoryIcons[cat.id] || Code;
                  return (
                    <DropdownMenu key={cat.id}>
                      <DropdownMenuTrigger asChild>
                        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-[#8b949e] hover:text-white hover:bg-white/5 transition-all whitespace-nowrap flex-shrink-0">
                          <Icon className="w-3.5 h-3.5" style={{ color: `var(--${cat.color})` }} />
                          {cat.name}
                          <ChevronDown className="w-3 h-3" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="bg-[#161b22] border-white/10">
                        {cat.subcategories.map((sub) => (
                          <DropdownMenuItem 
                            key={sub.id}
                            onClick={() => navigate(`/courses/${cat.id}/${sub.id}`)}
                            className="text-sm text-[#e6edf3] hover:bg-white/5 cursor-pointer"
                          >
                            {sub.name}
                          </DropdownMenuItem>
                        ))}
                        <DropdownMenuSeparator className="bg-white/10" />
                        <DropdownMenuItem 
                          onClick={() => navigate(`/courses/${cat.id}`)}
                          className="text-sm text-[#00c896] hover:bg-[#00c896]/10 cursor-pointer"
                        >
                          All {cat.name}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  );
                })}

                <div className="w-px h-4 bg-white/10 mx-2" />

                {bookCategories.map((cat) => {
                  const Icon = categoryIcons[cat.color] || BookOpen;
                  return (
                    <button 
                      key={cat.id}
                      onClick={() => navigate(`/books/${cat.id}`)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-[#8b949e] hover:text-white hover:bg-white/5 transition-all whitespace-nowrap flex-shrink-0"
                    >
                      <Icon className="w-3.5 h-3.5" style={{ color: `var(--${cat.color})` }} />
                      {cat.name}
                    </button>
                  );
                })}
              </div>

              <button 
                onClick={() => scrollCategories('right')}
                className="p-1 text-[#8b949e] hover:text-white transition-colors"
              >
                <ChevronDown className="w-4 h-4 -rotate-90" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu - Full Screen Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 top-[64px] bg-[#0d1117] z-[100] overflow-y-auto"
          style={{ height: 'calc(100vh - 64px)' }}
        >
          <div className="p-4 space-y-2">
            <Link to="/" onClick={() => setIsMobileMenuOpen(false)}>
              <Button 
                variant="ghost" 
                className={`w-full justify-start gap-3 ${isActive('/') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#e6edf3]'}`}
              >
                <Home className="w-5 h-5" />
                Home
              </Button>
            </Link>

            <div className="pt-2 border-t border-white/10">
              <p className="px-4 py-2 text-xs text-[#8b949e] uppercase tracking-wider font-medium">Courses</p>
              {categoriesData.map((cat) => {
                const Icon = categoryIcons[cat.id] || Code;
                return (
                  <Link key={cat.id} to={`/courses/${cat.id}`} onClick={() => setIsMobileMenuOpen(false)}>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start gap-3 text-[#e6edf3] hover:bg-white/5"
                    >
                      <Icon className="w-5 h-5" style={{ color: `var(--${cat.color})` }} />
                      {cat.name}
                    </Button>
                  </Link>
                );
              })}
            </div>

            <div className="pt-2 border-t border-white/10">
              <p className="px-4 py-2 text-xs text-[#8b949e] uppercase tracking-wider font-medium">Books</p>
              {bookCategories.map((cat) => {
                const Icon = categoryIcons[cat.color] || BookOpen;
                return (
                  <Link key={cat.id} to={`/books/${cat.id}`} onClick={() => setIsMobileMenuOpen(false)}>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start gap-3 text-[#e6edf3] hover:bg-white/5"
                    >
                      <Icon className="w-5 h-5" style={{ color: `var(--${cat.color})` }} />
                      {cat.name}
                    </Button>
                  </Link>
                );
              })}
            </div>

            <div className="pt-2 border-t border-white/10">
              {hasPurchases && (
                <Link to="/dashboard" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button 
                    variant="ghost" 
                    className={`w-full justify-start gap-3 ${isActive('/dashboard') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#e6edf3]'}`}
                  >
                    <BarChart3 className="w-5 h-5" />
                    Dashboard
                  </Button>
                </Link>
              )}
              <Link to="/support" onClick={() => setIsMobileMenuOpen(false)}>
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start gap-3 ${isActive('/support') ? 'text-[#00c896] bg-[#00c896]/10' : 'text-[#e6edf3]'}`}
                >
                  <HeadphonesIcon className="w-5 h-5" />
                  Support
                </Button>
              </Link>
            </div>

            {!user && (
              <div className="pt-4 border-t border-white/10 space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full border-white/10 text-[#e6edf3] hover:bg-white/5"
                  onClick={() => { onLoginClick(); setIsMobileMenuOpen(false); }}
                >
                  <User className="w-4 h-4 mr-2" />
                  Login
                </Button>
                <Button 
                  className="w-full bg-[#00c896] text-[#0d1117] hover:bg-[#00a97e]"
                  onClick={() => { onLoginClick(); setIsMobileMenuOpen(false); }}
                >
                  <User className="w-4 h-4 mr-2" />
                  Sign Up Free
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
