import { useState } from 'react';
import { UserPlus, LogIn, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (email: string, password: string) => boolean;
  onRegister: (name: string, email: string, password: string) => boolean;
}

export function AuthModal({ isOpen, onClose, onLogin, onRegister }: AuthModalProps) {
  const [activeTab, setActiveTab] = useState('login');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Login form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register form
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    setTimeout(() => {
      const success = onLogin(loginEmail, loginPassword);
      if (success) {
        onClose();
        setLoginEmail('');
        setLoginPassword('');
      } else {
        setError('Invalid email or password');
      }
      setIsLoading(false);
    }, 500);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (regPassword.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    
    setIsLoading(true);
    
    setTimeout(() => {
      const success = onRegister(regName, regEmail, regPassword);
      if (success) {
        onClose();
        setRegName('');
        setRegEmail('');
        setRegPassword('');
      } else {
        setError('Email already registered');
      }
      setIsLoading(false);
    }, 500);
  };

  const handleClose = () => {
    setError('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-[#161b22] border-white/10 p-0 overflow-hidden">
        <DialogHeader className="p-6 pb-0">
          <div className="flex items-center justify-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#00c896] to-[#00a97e] rounded-xl flex items-center justify-center text-[#0d1117] font-bold text-2xl">
              E
            </div>
          </div>
          <DialogTitle className="text-center text-xl font-bold text-white">
            Welcome to <span className="text-[#00c896]">edu</span>bazar<span className="text-[#8b949e]">.shop</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-[#21262d] mx-6 w-[calc(100%-3rem)]">
            <TabsTrigger 
              value="login" 
              className="data-[state=active]:bg-[#00c896] data-[state=active]:text-[#0d1117]"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Login
            </TabsTrigger>
            <TabsTrigger 
              value="register"
              className="data-[state=active]:bg-[#00c896] data-[state=active]:text-[#0d1117]"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Sign Up
            </TabsTrigger>
          </TabsList>

          {error && (
            <div className="mx-6 mt-4 p-3 bg-[#f85149]/10 border border-[#f85149]/30 rounded-lg">
              <p className="text-[#f85149] text-sm text-center">{error}</p>
            </div>
          )}

          <TabsContent value="login" className="p-6 pt-4">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="login-email" className="text-[#8b949e] text-xs uppercase tracking-wider">
                  Email Address
                </Label>
                <Input
                  id="login-email"
                  type="email"
                  placeholder="you@example.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                  className="bg-[#21262d] border-white/10 text-white placeholder:text-[#8b949e]/50 focus:border-[#00c896] focus:ring-[#00c896]/20"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-password" className="text-[#8b949e] text-xs uppercase tracking-wider">
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    required
                    className="bg-[#21262d] border-white/10 text-white placeholder:text-[#8b949e]/50 focus:border-[#00c896] focus:ring-[#00c896]/20 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8b949e] hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#00c896] text-[#0d1117] hover:bg-[#00a97e] font-semibold"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-[#0d1117]/30 border-t-[#0d1117] rounded-full animate-spin" />
                    Signing in...
                  </span>
                ) : (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign In
                  </>
                )}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="register" className="p-6 pt-4">
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reg-name" className="text-[#8b949e] text-xs uppercase tracking-wider">
                  Full Name
                </Label>
                <Input
                  id="reg-name"
                  type="text"
                  placeholder="Your name"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  required
                  className="bg-[#21262d] border-white/10 text-white placeholder:text-[#8b949e]/50 focus:border-[#00c896] focus:ring-[#00c896]/20"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-email" className="text-[#8b949e] text-xs uppercase tracking-wider">
                  Email Address
                </Label>
                <Input
                  id="reg-email"
                  type="email"
                  placeholder="you@example.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  required
                  className="bg-[#21262d] border-white/10 text-white placeholder:text-[#8b949e]/50 focus:border-[#00c896] focus:ring-[#00c896]/20"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-password" className="text-[#8b949e] text-xs uppercase tracking-wider">
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="reg-password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Min 6 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    required
                    minLength={6}
                    className="bg-[#21262d] border-white/10 text-white placeholder:text-[#8b949e]/50 focus:border-[#00c896] focus:ring-[#00c896]/20 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8b949e] hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#00c896] text-[#0d1117] hover:bg-[#00a97e] font-semibold"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-[#0d1117]/30 border-t-[#0d1117] rounded-full animate-spin" />
                    Creating account...
                  </span>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Create Account
                  </>
                )}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
