import { BookOpen, User, ShoppingCart, Check, Download, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Book } from '@/types';

interface BookCardProps {
  book: Book;
  isInCart: boolean;
  isPurchased: boolean;
  onAddToCart: (book: Book) => void;
}

export function BookCard({ book, isInCart, isPurchased, onAddToCart }: BookCardProps) {
  const discount = Math.round((1 - book.price / book.originalPrice) * 100);

  const getCategoryColor = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string }> = {
      hacking: { bg: 'bg-[#a371f7]/10', text: 'text-[#a371f7]', border: 'border-[#a371f7]/30' },
      programming: { bg: 'bg-[#58a6ff]/10', text: 'text-[#58a6ff]', border: 'border-[#58a6ff]/30' },
      trading: { bg: 'bg-[#3fb950]/10', text: 'text-[#3fb950]', border: 'border-[#3fb950]/30' },
    };
    return colors[color] || colors.programming;
  };

  const catStyle = getCategoryColor(book.color);

  const getCategoryName = (subcategory: string) => {
    const names: Record<string, string> = {
      'hacking-books': 'HACKING BOOK',
      'programming-books': 'PROGRAMMING BOOK',
      'trading-books': 'TRADING BOOK',
    };
    return names[subcategory] || 'BOOK';
  };

  return (
    <div className="group bg-[#161b22] border border-white/5 rounded-2xl overflow-hidden card-hover">
      {/* Image */}
      <div className="relative h-40 overflow-hidden">
        {/* Badge */}
        <div className="absolute top-3 left-3 z-10">
          {isPurchased ? (
            <Badge className="bg-[#3fb950] text-white border-0">
              <Check className="w-3 h-3 mr-1" />
              Owned
            </Badge>
          ) : (
            <Badge className="bg-[#58a6ff] text-white border-0">
              {discount}% OFF
            </Badge>
          )}
        </div>

        {/* Book Cover */}
        <div 
          className="w-full h-full flex flex-col items-center justify-center gap-2 p-4"
          style={{
            background: book.color === 'hacking' 
              ? 'linear-gradient(135deg, #13111a 0%, #2d1b69 100%)'
              : book.color === 'programming'
              ? 'linear-gradient(135deg, #0d1117 0%, #0d3460 100%)'
              : 'linear-gradient(135deg, #0d1a0d 0%, #0d3b1a 100%)'
          }}
        >
          <div 
            className="w-20 h-28 rounded-lg flex items-center justify-center shadow-lg"
            style={{ 
              background: `var(--${book.color})20`,
              border: `2px solid var(--${book.color})40`,
              boxShadow: `0 8px 32px var(--${book.color})20`
            }}
          >
            <BookOpen className="w-8 h-8" style={{ color: `var(--${book.color})` }} />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Category */}
        <span className={`inline-block px-2 py-1 rounded text-[10px] font-bold tracking-wider ${catStyle.bg} ${catStyle.text}`}>
          {getCategoryName(book.subcategory)}
        </span>

        {/* Title */}
        <h3 className="text-white font-semibold mt-2 mb-2 line-clamp-2 min-h-[48px]">
          {book.title}
        </h3>

        {/* Author */}
        <p className="text-[#8b949e] text-sm mb-3 flex items-center gap-1">
          <User className="w-3.5 h-3.5" />
          {book.author}
        </p>

        {/* Meta */}
        <div className="flex items-center gap-3 mb-4 text-xs text-[#8b949e]">
          <span className="flex items-center gap-1">
            <BookOpen className="w-3.5 h-3.5 text-[#00c896]" />
            {book.pages} pages
          </span>
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-[#d29922]" />
            {book.rating || 4.7}
          </span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-[#00c896]">₹{book.price.toLocaleString()}</span>
            <span className="text-sm text-[#8b949e] line-through">₹{book.originalPrice.toLocaleString()}</span>
          </div>
        </div>

        {/* Action */}
        {isPurchased ? (
          <a
            href={book.downloadLink || '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full"
          >
            <Button 
              className="w-full bg-gradient-to-r from-[#667eea] to-[#764ba2] hover:opacity-90 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Now
            </Button>
          </a>
        ) : isInCart ? (
          <Button 
            disabled
            className="w-full bg-[#21262d] text-[#8b949e] cursor-not-allowed"
          >
            <Check className="w-4 h-4 mr-2" />
            Added to Cart
          </Button>
        ) : (
          <Button 
            onClick={() => onAddToCart(book)}
            className="w-full bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117] font-semibold"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        )}
      </div>
    </div>
  );
}
