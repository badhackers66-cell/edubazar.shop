import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { botResponses } from '@/data';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  time: string;
}

const quickReplies = [
  'Course prices?',
  'Payment methods?',
  'Refund policy?',
  'Android course offer?',
];

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      text: "👋 Hi! I'm EduBot. I can help you with courses, payments, and more!",
      sender: 'bot',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Auto-open after 12 seconds on first visit
  useEffect(() => {
    const hasOpened = localStorage.getItem('chatOpened');
    if (!hasOpened) {
      const timer = setTimeout(() => {
        setIsOpen(true);
        localStorage.setItem('chatOpened', 'true');
      }, 12000);
      return () => clearTimeout(timer);
    }
  }, []);

  const generateResponse = (msg: string): string => {
    const lower = msg.toLowerCase();
    if (lower.includes('android')) return botResponses.android;
    if (lower.includes('price') || lower.includes('cost') || lower.includes('₹')) return botResponses.price;
    if (lower.includes('payment') || lower.includes('pay') || lower.includes('upi')) return botResponses.payment;
    if (lower.includes('refund') || lower.includes('money back')) return botResponses.refund;
    if (lower.includes('contact') || lower.includes('email') || lower.includes('phone')) return botResponses.contact;
    if (lower.includes('certificate')) return botResponses.certificate;
    if (lower.includes('access') || lower.includes('lifetime')) return botResponses.access;
    if (lower.includes('discount') || lower.includes('offer')) return botResponses.discount;
    if (lower.includes('book')) return botResponses.books;
    if (lower.includes('hello') || lower.includes('hi') || lower.includes('hey')) return botResponses.hello;
    return botResponses.default;
  };

  const sendMessage = (text: string = input) => {
    if (!text.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: generateResponse(text),
        sender: 'bot',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 800 + Math.random() * 800);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 ${
          isOpen 
            ? 'bg-[#f85149] hover:bg-[#e04a40]' 
            : 'bg-gradient-to-br from-[#00c896] to-[#00a97e] hover:scale-110 animate-chat-pulse'
        }`}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <MessageCircle className="w-6 h-6 text-[#0d1117]" />
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 bg-[#161b22] border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-fade-in">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0d1a14] to-[#0d2a1e] p-4 border-b border-white/5 flex items-center gap-3">
            <div className="w-10 h-10 bg-[#00c896] rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5 text-[#0d1117]" />
            </div>
            <div>
              <h4 className="text-white font-semibold">EduBot AI</h4>
              <p className="text-[#3fb950] text-xs flex items-center gap-1">
                <span className="w-2 h-2 bg-[#3fb950] rounded-full animate-pulse" />
                Online
              </p>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="h-80 p-4" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                      msg.sender === 'user'
                        ? 'bg-[#00c896] text-[#0d1117] rounded-br-md'
                        : 'bg-[#21262d] text-[#e6edf3] rounded-bl-md'
                    }`}
                  >
                    {msg.text}
                    <div className={`text-[10px] mt-1 ${msg.sender === 'user' ? 'text-[#0d1117]/60' : 'text-[#8b949e]'}`}>
                      {msg.time}
                    </div>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-[#21262d] p-3 rounded-2xl rounded-bl-md">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-[#8b949e] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 bg-[#8b949e] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 bg-[#8b949e] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Quick Replies */}
          <div className="p-2 border-t border-white/5 flex flex-wrap gap-2">
            {quickReplies.map((reply) => (
              <button
                key={reply}
                onClick={() => sendMessage(reply)}
                className="px-3 py-1.5 bg-[#21262d] hover:bg-[#00c896]/10 border border-white/5 hover:border-[#00c896]/30 rounded-full text-xs text-[#8b949e] hover:text-[#00c896] transition-all"
              >
                {reply}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="p-3 border-t border-white/5 flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask anything..."
              className="flex-1 bg-[#21262d] border-white/10 text-white placeholder:text-[#8b949e]/50 focus:border-[#00c896] focus:ring-[#00c896]/20"
            />
            <Button
              onClick={() => sendMessage()}
              size="icon"
              className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
