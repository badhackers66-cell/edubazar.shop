import { Clock, Users, Star, ShoppingCart, Check, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Course } from '@/types';

interface CourseCardProps {
  course: Course;
  isInCart: boolean;
  isPurchased: boolean;
  onAddToCart: (course: Course) => void;
}

const categoryLabels: Record<string, string> = {
  hacking: 'HACKING',
  programming: 'PROGRAMMING',
  trading: 'TRADING',
  business: 'BUSINESS',
  ai: 'AI',
  android: 'ANDROID',
};

export function CourseCard({ course, isInCart, isPurchased, onAddToCart }: CourseCardProps) {
  const discount = Math.round((1 - course.price / course.originalPrice) * 100);
  const isHot = parseFloat(course.students.replace('k', '')) > 5;

  const getCategoryColor = (color: string) => {
    const colors: Record<string, { bg: string; text: string }> = {
      hacking: { bg: 'bg-[#a371f7]/10', text: 'text-[#a371f7]' },
      programming: { bg: 'bg-[#58a6ff]/10', text: 'text-[#58a6ff]' },
      trading: { bg: 'bg-[#3fb950]/10', text: 'text-[#3fb950]' },
      business: { bg: 'bg-[#ffa657]/10', text: 'text-[#ffa657]' },
      ai: { bg: 'bg-[#f78166]/10', text: 'text-[#f78166]' },
      android: { bg: 'bg-[#3ddc84]/10', text: 'text-[#3ddc84]' },
    };
    return colors[color] || colors.programming;
  };

  const catStyle = getCategoryColor(course.color);

  return (
    <div className="group bg-[#161b22] border border-white/5 rounded-2xl overflow-hidden card-hover">
      {/* Image */}
      <div className="relative h-44 overflow-hidden">
        {/* Badge */}
        <div className="absolute top-3 left-3 z-10">
          {isPurchased ? (
            <Badge className="bg-[#3fb950] text-white border-0">
              <Check className="w-3 h-3 mr-1" />
              Owned
            </Badge>
          ) : course.isSpecialOffer ? (
            <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white border-0">
              🔥 {course.discount}% OFF
            </Badge>
          ) : isHot ? (
            <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white border-0">
              🔥 Hot
            </Badge>
          ) : (
            <Badge className="bg-[#58a6ff] text-white border-0">New</Badge>
          )}
        </div>

        {/* Course Image SVG */}
        <div 
          className="w-full h-full flex flex-col items-center justify-center gap-3 p-4"
          style={{
            background: course.color === 'hacking' 
              ? 'linear-gradient(135deg, #13111a 0%, #2d1b69 100%)'
              : course.color === 'programming'
              ? 'linear-gradient(135deg, #0d1117 0%, #0d3460 100%)'
              : course.color === 'trading'
              ? 'linear-gradient(135deg, #0d1a0d 0%, #0d3b1a 100%)'
              : course.color === 'business'
              ? 'linear-gradient(135deg, #1a1200 0%, #3d2900 100%)'
              : course.color === 'ai'
              ? 'linear-gradient(135deg, #1a0d0d 0%, #3d1515 100%)'
              : 'linear-gradient(135deg, #0d1a0d 0%, #0d3b1a 100%)'
          }}
        >
          <div 
            className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ 
              background: `var(--${course.color})20`,
              border: `1px solid var(--${course.color})40`
            }}
          >
            <span className="text-3xl" style={{ color: `var(--${course.color})` }}>
              {course.icon === 'shield' && '🛡️'}
              {course.icon === 'bug' && '🐛'}
              {course.icon === 'network' && '🌐'}
              {course.icon === 'virus' && '🦠'}
              {course.icon === 'terminal' && '💻'}
              {course.icon === 'code' && '</>'}
              {course.icon === 'smartphone' && '📱'}
              {course.icon === 'brain' && '🧠'}
              {course.icon === 'file-json' && '{ }'}
              {course.icon === 'server' && '🔧'}
              {course.icon === 'layout' && '📐'}
              {course.icon === 'trending-up' && '📈'}
              {course.icon === 'dollar-sign' && '💵'}
              {course.icon === 'bitcoin' && '₿'}
              {course.icon === 'bar-chart-2' && '📊'}
              {course.icon === 'activity' && '⚡'}
              {course.icon === 'rocket' && '🚀'}
              {course.icon === 'megaphone' && '📢'}
              {course.icon === 'shopping-cart' && '🛒'}
              {course.icon === 'users' && '👥'}
              {course.icon === 'share-2' && '🔗'}
              {course.icon === 'cpu' && '⚙️'}
              {course.icon === 'brain-circuit' && '🧬'}
              {course.icon === 'message-square' && '💬'}
              {course.icon === 'eye' && '👁️'}
              {course.icon === 'briefcase' && '💼'}
            </span>
          </div>
          <p 
            className="text-xs font-semibold uppercase tracking-wider text-center line-clamp-1"
            style={{ color: `var(--${course.color})` }}
          >
            {course.title.substring(0, 30)}
          </p>
          <div 
            className="w-10 h-0.5 rounded-full"
            style={{ background: `var(--${course.color})`, opacity: 0.5 }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Category */}
        <span className={`inline-block px-2 py-1 rounded text-[10px] font-bold tracking-wider ${catStyle.bg} ${catStyle.text}`}>
          {categoryLabels[course.color] || course.category.toUpperCase()}
        </span>

        {/* Title */}
        <h3 className="text-white font-semibold mt-2 mb-3 line-clamp-2 min-h-[48px]">
          {course.title}
        </h3>

        {/* Meta */}
        <div className="flex flex-wrap gap-3 mb-4 text-xs text-[#8b949e]">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-[#00c896]" />
            {course.duration}
          </span>
          <span className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-[#00c896]" />
            {course.students}
          </span>
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-[#d29922]" />
            {course.rating || 4.8}
          </span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-[#00c896]">₹{course.price.toLocaleString()}</span>
            <span className="text-sm text-[#8b949e] line-through">₹{course.originalPrice.toLocaleString()}</span>
          </div>
          <span className="text-xs font-semibold text-[#3fb950] bg-[#3fb950]/10 px-2 py-1 rounded">
            {discount}% OFF
          </span>
        </div>

        {/* Action */}
        {isPurchased ? (
          <a
            href={course.downloadLink || '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full"
          >
            <Button 
              className="w-full bg-gradient-to-r from-[#667eea] to-[#764ba2] hover:opacity-90 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Now
            </Button>
          </a>
        ) : isInCart ? (
          <Button 
            disabled
            className="w-full bg-[#21262d] text-[#8b949e] cursor-not-allowed"
          >
            <Check className="w-4 h-4 mr-2" />
            Added to Cart
          </Button>
        ) : (
          <Button 
            onClick={() => onAddToCart(course)}
            className="w-full bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117] font-semibold"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        )}
      </div>
    </div>
  );
}
