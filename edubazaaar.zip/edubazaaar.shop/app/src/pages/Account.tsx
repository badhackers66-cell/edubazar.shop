import { useNavigate } from 'react-router-dom';
import { 
  User, LogOut, BookOpen, Download, ArrowRight 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import type { Course, Purchase } from '@/types';

interface AccountPageProps {
  user: { name: string; email: string } | null;
  purchases: Purchase[];
  totalSpent: number;
  onLoginClick: () => void;
  onLogout: () => void;
}

const categoryColors: Record<string, string> = {
  hacking: '#a371f7',
  programming: '#58a6ff',
  trading: '#3fb950',
  business: '#ffa657',
  ai: '#f78166',
  android: '#3ddc84',
};

export function Account({ user, purchases, totalSpent, onLoginClick, onLogout }: AccountPageProps) {
  const navigate = useNavigate();

  if (!user) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-24 h-24 bg-[#21262d] rounded-full flex items-center justify-center mx-auto mb-6">
            <User className="w-12 h-12 text-[#8b949e]" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Login Required</h1>
          <p className="text-[#8b949e] mb-8">Please login to access your purchased courses and dashboard.</p>
          <Button 
            onClick={onLoginClick}
            className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
          >
            <User className="w-4 h-4 mr-2" />
            Login / Register
          </Button>
        </div>
      </div>
    );
  }

  // Get all purchased courses
  const allCourses: (Course & { purchaseDate: string; paymentId: string })[] = [];
  purchases.forEach(p => {
    p.courses.forEach(c => {
      allCourses.push({ ...c, purchaseDate: p.date, paymentId: p.paymentId });
    });
  });

  const certificates = Math.floor(allCourses.length * 0.5);

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <div className="bg-gradient-to-br from-[#0d1a14] to-[#0d2a1e] border border-[#00c896]/20 rounded-3xl p-8 mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-[#00c896] to-[#00a97e] rounded-2xl flex items-center justify-center text-[#0d1117] text-3xl font-bold">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-white mb-1">{user.name}</h1>
              <p className="text-[#8b949e]">{user.email}</p>
            </div>
            <Button 
              onClick={onLogout}
              variant="outline"
              className="border-white/10 text-[#f85149] hover:bg-[#f85149]/10"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t border-white/10">
            <div className="text-center">
              <div className="text-3xl font-bold text-[#00c896]">{allCourses.length}</div>
              <div className="text-sm text-[#8b949e]">Courses Purchased</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#00c896]">₹{totalSpent.toLocaleString()}</div>
              <div className="text-sm text-[#8b949e]">Total Invested</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#00c896]">{certificates}</div>
              <div className="text-sm text-[#8b949e]">Certificates</div>
            </div>
          </div>
        </div>

        {/* My Courses */}
        <div>
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#00c896]" />
            My Courses
          </h2>

          {allCourses.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {allCourses.map((course, index) => {
                const progress = Math.floor(Math.random() * 60) + 20;
                return (
                  <div 
                    key={`${course.id}-${index}`}
                    className="bg-[#161b22] border border-white/5 rounded-2xl p-4 flex gap-4"
                  >
                    <div 
                      className="w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ 
                        background: `${categoryColors[course.color] || '#58a6ff'}20`,
                        border: `1px solid ${categoryColors[course.color] || '#58a6ff'}40`
                      }}
                    >
                      <span className="text-2xl">📚</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-semibold text-sm truncate">{course.title}</h3>
                      <p className="text-[#8b949e] text-xs capitalize mb-2">
                        {course.category} • Purchased {new Date(course.purchaseDate).toLocaleDateString('en-IN')}
                      </p>
                      <div className="mb-1">
                        <Progress value={progress} className="h-1.5" />
                      </div>
                      <p className="text-[#8b949e] text-xs">{progress}% complete</p>
                    </div>
                    <a
                      href={course.downloadLink || '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-shrink-0"
                    >
                      <Button 
                        size="sm"
                        className="bg-gradient-to-r from-[#667eea] to-[#764ba2] hover:opacity-90 text-white"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </a>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-[#161b22] border border-white/5 rounded-2xl p-12 text-center">
              <div className="w-16 h-16 bg-[#21262d] rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-[#8b949e]" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">No courses yet</h3>
              <p className="text-[#8b949e] mb-6">Start your learning journey today</p>
              <Button 
                onClick={() => navigate('/courses')}
                className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
              >
                Browse Courses
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
