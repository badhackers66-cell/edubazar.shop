import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BookCard } from '@/components/ui-custom';
import { booksData, bookCategories } from '@/data';
import type { Book } from '@/types';

interface BooksPageProps {
  onAddToCart: (book: Book) => void;
  isInCart: (id: number) => boolean;
  isPurchased: (id: number) => boolean;
}

export function Books({ onAddToCart, isInCart, isPurchased }: BooksPageProps) {
  const { category } = useParams<{ category?: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  // Filter books based on category and search
  const filteredBooks = useMemo(() => {
    let books = [...booksData];

    if (category) {
      books = books.filter(b => b.subcategory === category);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      books = books.filter(b => 
        b.title.toLowerCase().includes(query) ||
        b.author.toLowerCase().includes(query) ||
        b.subcategory.toLowerCase().includes(query)
      );
    }

    return books;
  }, [category, searchQuery]);

  // Get category info
  const categoryInfo = category ? bookCategories.find(c => c.id === category) : null;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button 
            onClick={() => navigate(-1)}
            variant="ghost"
            className="text-[#00c896] hover:text-[#00a97e] hover:bg-[#00c896]/10 mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                {categoryInfo ? categoryInfo.name : 'All Books'}
              </h1>
              <p className="text-[#8b949e]">
                {filteredBooks.length} book{filteredBooks.length !== 1 ? 's' : ''} available
              </p>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b949e]" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books..."
                className="pl-10 w-full sm:w-80 bg-[#161b22] border-white/10 text-white placeholder:text-[#8b949e]/50"
              />
            </div>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          <Button
            variant={!category ? 'default' : 'outline'}
            size="sm"
            onClick={() => navigate('/books')}
            className={!category ? 'bg-[#00c896] text-[#0d1117]' : 'border-white/10 text-[#8b949e]'}
          >
            All Books
          </Button>
          {bookCategories.map((cat) => (
            <Button
              key={cat.id}
              variant={category === cat.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => navigate(`/books/${cat.id}`)}
              className={category === cat.id ? 'bg-[#00c896] text-[#0d1117]' : 'border-white/10 text-[#8b949e]'}
            >
              {cat.name}
            </Button>
          ))}
        </div>

        {/* Books Grid */}
        {filteredBooks.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                isInCart={isInCart(book.id)}
                isPurchased={isPurchased(book.id)}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-[#21262d] rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-10 h-10 text-[#8b949e]" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No books found</h3>
            <p className="text-[#8b949e]">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
