import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Trash2, Lock, BookOpen, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import type { CartItem } from '@/types';
import { useToast } from '@/hooks';

interface CartPageProps {
  cart: CartItem[];
  subtotal: number;
  total: number;
  discount: number;
  onRemove: (id: number) => void;
  onCheckout: () => void;
  onClear: () => void;
}

const categoryColors: Record<string, string> = {
  hacking: '#a371f7',
  programming: '#58a6ff',
  trading: '#3fb950',
  business: '#ffa657',
  ai: '#f78166',
  android: '#3ddc84',
  books: '#58a6ff',
};

export function Cart({ cart, subtotal, total, discount, onRemove, onCheckout, onClear }: CartPageProps) {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const handleCheckout = () => {
    if (cart.length === 0) {
      showToast('Your cart is empty!', 'error');
      return;
    }
    onCheckout();
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-24 h-24 bg-[#21262d] rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingCart className="w-12 h-12 text-[#8b949e]" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Your cart is empty</h1>
          <p className="text-[#8b949e] mb-8">Add some courses or books to get started</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => navigate('/courses')}
              className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
            >
              Browse Courses
            </Button>
            <Button 
              onClick={() => navigate('/books')}
              variant="outline"
              className="border-white/10 text-white hover:bg-white/5"
            >
              Browse Books
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button 
            onClick={() => navigate(-1)}
            variant="ghost"
            className="text-[#00c896] hover:text-[#00a97e] hover:bg-[#00c896]/10 mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Continue Shopping
          </Button>

          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-white">Shopping Cart</h1>
            <Button 
              onClick={onClear}
              variant="ghost"
              size="sm"
              className="text-[#f85149] hover:text-[#f85149] hover:bg-[#f85149]/10"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear Cart
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <div 
                key={item.id}
                className="bg-[#161b22] border border-white/5 rounded-2xl p-4 flex gap-4"
              >
                {/* Icon */}
                <div 
                  className="w-20 h-16 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ 
                    background: `${categoryColors[item.color] || '#58a6ff'}20`,
                    border: `1px solid ${categoryColors[item.color] || '#58a6ff'}40`
                  }}
                >
                  <span className="text-2xl">
                    {item.type === 'book' ? '📚' : '📖'}
                  </span>
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-semibold truncate">{item.title}</h3>
                  <p className="text-[#8b949e] text-sm capitalize flex items-center gap-2">
                    {item.type === 'book' ? (
                      <>
                        <BookOpen className="w-3.5 h-3.5" />
                        {item.pages} pages
                      </>
                    ) : (
                      <>
                        <Clock className="w-3.5 h-3.5" />
                        {item.duration}
                      </>
                    )}
                  </p>
                </div>

                {/* Price & Remove */}
                <div className="text-right">
                  <p className="text-[#00c896] font-bold text-lg">₹{item.price.toLocaleString()}</p>
                  <p className="text-[#8b949e] text-sm line-through">₹{item.originalPrice.toLocaleString()}</p>
                  <button
                    onClick={() => onRemove(item.id)}
                    className="text-[#f85149] hover:text-[#f85149]/80 text-sm mt-2 flex items-center gap-1 ml-auto"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6 sticky top-24">
              <h3 className="text-lg font-semibold text-white mb-4">Order Summary</h3>
              
              <div className="space-y-3 mb-4">
                <div className="flex justify-between text-[#8b949e]">
                  <span>Subtotal</span>
                  <span>₹{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[#3fb950]">
                  <span>Discount</span>
                  <span>-₹{discount.toLocaleString()}</span>
                </div>
              </div>

              <Separator className="bg-white/10 my-4" />

              <div className="flex justify-between text-white text-lg font-bold mb-6">
                <span>Total</span>
                <span>₹{total.toLocaleString()}</span>
              </div>

              <Button 
                onClick={handleCheckout}
                className="w-full bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117] font-semibold py-6"
              >
                <Lock className="w-4 h-4 mr-2" />
                Proceed to Checkout
              </Button>

              <p className="text-center text-[#8b949e] text-xs mt-4">
                Secure payment via Razorpay
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
