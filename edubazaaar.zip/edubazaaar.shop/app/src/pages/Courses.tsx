import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Grid3X3, List } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CourseCard } from '@/components/ui-custom';
import { coursesData, categoriesData } from '@/data';
import type { Course } from '@/types';

interface CoursesPageProps {
  onAddToCart: (course: Course) => void;
  isInCart: (id: number) => boolean;
  isPurchased: (id: number) => boolean;
}

export function Courses({ onAddToCart, isInCart, isPurchased }: CoursesPageProps) {
  const { category, subcategory } = useParams<{ category?: string; subcategory?: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Filter courses based on category, subcategory, and search
  const filteredCourses = useMemo(() => {
    let courses = [...coursesData];

    if (category) {
      courses = courses.filter(c => c.category === category);
    }

    if (subcategory) {
      courses = courses.filter(c => c.subcategory === subcategory);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      courses = courses.filter(c => 
        c.title.toLowerCase().includes(query) ||
        c.category.toLowerCase().includes(query) ||
        c.subcategory.toLowerCase().includes(query)
      );
    }

    return courses;
  }, [category, subcategory, searchQuery]);

  // Get category info
  const categoryInfo = category ? categoriesData.find(c => c.id === category) : null;
  
  // Get subcategory name
  const subcategoryName = subcategory && categoryInfo
    ? categoryInfo.subcategories.find(s => s.id === subcategory)?.name
    : null;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button 
            onClick={() => navigate(-1)}
            variant="ghost"
            className="text-[#00c896] hover:text-[#00a97e] hover:bg-[#00c896]/10 mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                {subcategoryName 
                  ? subcategoryName 
                  : categoryInfo 
                    ? categoryInfo.name 
                    : 'All Courses'}
              </h1>
              <p className="text-[#8b949e]">
                {filteredCourses.length} course{filteredCourses.length !== 1 ? 's' : ''} available
              </p>
            </div>

            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b949e]" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search courses..."
                  className="pl-10 w-full sm:w-64 bg-[#161b22] border-white/10 text-white placeholder:text-[#8b949e]/50"
                />
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className={viewMode === 'grid' ? 'bg-[#00c896] text-[#0d1117]' : 'border-white/10 text-[#8b949e]'}
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className={viewMode === 'list' ? 'bg-[#00c896] text-[#0d1117]' : 'border-white/10 text-[#8b949e]'}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Subcategory Filters */}
        {categoryInfo && (
          <div className="flex flex-wrap gap-2 mb-8">
            <Button
              variant={!subcategory ? 'default' : 'outline'}
              size="sm"
              onClick={() => navigate(`/courses/${category}`)}
              className={!subcategory ? 'bg-[#00c896] text-[#0d1117]' : 'border-white/10 text-[#8b949e]'}
            >
              All
            </Button>
            {categoryInfo.subcategories.map((sub) => (
              <Button
                key={sub.id}
                variant={subcategory === sub.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => navigate(`/courses/${category}/${sub.id}`)}
                className={subcategory === sub.id ? 'bg-[#00c896] text-[#0d1117]' : 'border-white/10 text-[#8b949e]'}
              >
                {sub.name}
              </Button>
            ))}
          </div>
        )}

        {/* Course Grid */}
        {filteredCourses.length > 0 ? (
          <div className={`grid gap-6 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
              : 'grid-cols-1'
          }`}>
            {filteredCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                isInCart={isInCart(course.id)}
                isPurchased={isPurchased(course.id)}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-[#21262d] rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-[#8b949e]" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No courses found</h3>
            <p className="text-[#8b949e]">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
