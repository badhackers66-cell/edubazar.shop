import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, CheckCircle, Clock, Award, TrendingUp,
  BookOpen, Flame, Target, Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import type { Course, Purchase } from '@/types';

interface DashboardPageProps {
  purchases: Purchase[];
}

const categoryColors: Record<string, string> = {
  hacking: '#a371f7',
  programming: '#58a6ff',
  trading: '#3fb950',
  business: '#ffa657',
  ai: '#f78166',
  android: '#3ddc84',
};

export function Dashboard({ purchases }: DashboardPageProps) {
  const navigate = useNavigate();

  // Get all purchased courses
  const allCourses: (Course & { purchaseDate: string; paymentId: string })[] = [];
  let totalHours = 0;
  
  purchases.forEach(p => {
    p.courses.forEach(c => {
      allCourses.push({ ...c, purchaseDate: p.date, paymentId: p.paymentId });
      const hours = parseInt(c.duration) || 0;
      totalHours += hours;
    });
  });

  const completedCourses = Math.floor(allCourses.length * 0.3);
  const certificates = Math.floor(allCourses.length * 0.5);
  const currentStreak = 3;

  // Category breakdown
  const categoryBreakdown = allCourses.reduce((acc, course) => {
    acc[course.category] = (acc[course.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button 
            onClick={() => navigate(-1)}
            variant="ghost"
            className="text-[#00c896] hover:text-[#00a97e] hover:bg-[#00c896]/10 mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <h1 className="text-3xl font-bold text-white mb-2">Learning Dashboard</h1>
          <p className="text-[#8b949e]">Track your progress and achievements</p>
        </div>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Completed Courses */}
          <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-[#3fb950]/10 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-[#3fb950]" />
              </div>
              <span className="text-3xl font-bold text-[#3fb950]">{completedCourses}</span>
            </div>
            <p className="text-[#8b949e] text-sm">Courses Completed</p>
          </div>

          {/* Hours Learned */}
          <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-[#00c896]/10 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-[#00c896]" />
              </div>
              <span className="text-3xl font-bold text-[#00c896]">{totalHours}h</span>
            </div>
            <p className="text-[#8b949e] text-sm">Hours Learned</p>
          </div>

          {/* Certificates */}
          <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-[#d29922]/10 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-[#d29922]" />
              </div>
              <span className="text-3xl font-bold text-[#d29922]">{certificates}</span>
            </div>
            <p className="text-[#8b949e] text-sm">Certificates Earned</p>
          </div>

          {/* Current Streak */}
          <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-[#f78166]/10 rounded-xl flex items-center justify-center">
                <Flame className="w-6 h-6 text-[#f78166]" />
              </div>
              <span className="text-3xl font-bold text-[#f78166]">{currentStreak}</span>
            </div>
            <p className="text-[#8b949e] text-sm">Day Streak</p>
            <div className="mt-3">
              <Progress value={60} className="h-1.5" />
              <p className="text-[#8b949e] text-xs mt-1">60% to next milestone</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Continue Learning */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#00c896]" />
              Continue Learning
            </h2>

            {allCourses.length > 0 ? (
              <div className="space-y-4">
                {allCourses.slice(0, 3).map((course, index) => {
                  const progress = Math.floor(Math.random() * 60) + 20;
                  return (
                    <div 
                      key={`${course.id}-${index}`}
                      className="bg-[#161b22] border border-white/5 rounded-2xl p-4"
                    >
                      <div className="flex items-center gap-4">
                        <div 
                          className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ 
                            background: `${categoryColors[course.color] || '#58a6ff'}20`,
                            border: `1px solid ${categoryColors[course.color] || '#58a6ff'}40`
                          }}
                        >
                          <span className="text-xl">📚</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-white font-semibold truncate">{course.title}</h3>
                          <p className="text-[#8b949e] text-sm capitalize">{course.category}</p>
                          <div className="mt-2">
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-[#8b949e]">{progress}% complete</span>
                              <span className="text-[#00c896]">{course.duration}</span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                        </div>
                        <Button 
                          size="sm"
                          className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117] flex-shrink-0"
                        >
                          <Zap className="w-4 h-4 mr-1" />
                          Resume
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-[#161b22] border border-white/5 rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-[#21262d] rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8 text-[#8b949e]" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">No courses in progress</h3>
                <p className="text-[#8b949e] mb-6">Start learning today!</p>
                <Button 
                  onClick={() => navigate('/courses')}
                  className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
                >
                  Browse Courses
                </Button>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Learning Goals */}
            <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-[#00c896]" />
                Learning Goals
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#8b949e]">Weekly Goal</span>
                    <span className="text-[#00c896]">5/10 hours</span>
                  </div>
                  <Progress value={50} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#8b949e]">Monthly Goal</span>
                    <span className="text-[#00c896]">12/30 hours</span>
                  </div>
                  <Progress value={40} className="h-2" />
                </div>
              </div>
            </div>

            {/* Category Breakdown */}
            {Object.keys(categoryBreakdown).length > 0 && (
              <div className="bg-[#161b22] border border-white/5 rounded-2xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#00c896]" />
                  Your Interests
                </h3>
                <div className="space-y-3">
                  {Object.entries(categoryBreakdown)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 4)
                    .map(([cat, count]) => (
                      <div key={cat} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ background: categoryColors[cat] || '#00c896' }}
                          />
                          <span className="text-[#8b949e] text-sm capitalize">{cat}</span>
                        </div>
                        <span className="text-white font-medium">{count}</span>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* Achievement Badge */}
            <div className="bg-gradient-to-br from-[#00c896]/20 to-[#00a97e]/10 border border-[#00c896]/30 rounded-2xl p-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-[#00c896] rounded-xl flex items-center justify-center">
                  <Award className="w-7 h-7 text-[#0d1117]" />
                </div>
                <div>
                  <h4 className="text-white font-semibold">Early Adopter</h4>
                  <p className="text-[#8b949e] text-sm">Joined edubazar.shop</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
