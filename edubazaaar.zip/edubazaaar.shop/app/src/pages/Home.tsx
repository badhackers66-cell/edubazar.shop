import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, Zap, Users, Star, Shield, Code, 
  TrendingUp, Briefcase, Brain, BookOpen, CheckCircle,
  Smartphone, ShoppingCart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { coursesData, categoriesData, bookCategories } from '@/data';
import type { Course } from '@/types';

interface HomeProps {
  onAddToCart: (course: Course) => void;
  isInCart: (id: number) => boolean;
  isPurchased: (id: number) => boolean;
}

const categoryIcons: Record<string, React.ElementType> = {
  hacking: Shield,
  programming: Code,
  trading: TrendingUp,
  business: Briefcase,
  ai: Brain,
};

export function Home({ onAddToCart, isInCart, isPurchased }: HomeProps) {
  const navigate = useNavigate();
  
  // Get featured courses (first 4)
  const featuredCourses = coursesData.slice(0, 4);
  
  // Get special offer course (Android)
  const androidCourse = coursesData.find(c => c.id === 100);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-[#00c896]/5 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-[#58a6ff]/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto">
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 bg-[#161b22] border border-[#00c896]/30 text-[#00c896] px-4 py-2 rounded-full text-sm font-medium mb-8 animate-pulse-glow">
              <Zap className="w-4 h-4" />
              India's #1 Premium Course Platform
            </div>

            {/* Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Learn <span className="gradient-text">Skills</span> That Pay Bills
            </h1>

            {/* Description */}
            <p className="text-lg text-[#8b949e] mb-8 max-w-2xl mx-auto leading-relaxed">
              Master Hacking, Programming, Trading, Business & AI with expert-led courses. 
              Lifetime access. Certificates included. Start today.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                onClick={() => navigate('/courses')}
                size="lg"
                className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117] font-semibold px-8"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Explore Courses
              </Button>
              <Button 
                onClick={() => navigate('/books')}
                variant="outline"
                size="lg"
                className="border-white/10 text-white hover:bg-white/5 px-8"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Browse Books
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-8 pt-8 border-t border-white/5">
              <div className="text-center">
                <div className="text-3xl font-bold text-[#00c896]">50+</div>
                <div className="text-sm text-[#8b949e]">Premium Courses</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#00c896]">10k+</div>
                <div className="text-sm text-[#8b949e]">Happy Students</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#00c896]">4.9★</div>
                <div className="text-sm text-[#8b949e]">Average Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#00c896]">15+</div>
                <div className="text-sm text-[#8b949e]">Premium Books</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Android Special Offer */}
      {androidCourse && (
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="relative bg-gradient-to-br from-[#0d1a0d] to-[#0d3b1a] border border-[#3ddc84]/30 rounded-3xl overflow-hidden">
              {/* Badge */}
              <div className="absolute top-4 right-4 bg-[#3ddc84] text-[#0d1117] px-4 py-2 rounded-full font-bold text-sm">
                🔥 80% OFF
              </div>

              <div className="grid lg:grid-cols-2 gap-8 p-8 lg:p-12">
                <div>
                  <Badge className="bg-[#3ddc84]/20 text-[#3ddc84] border-[#3ddc84]/30 mb-4">
                    <Smartphone className="w-4 h-4 mr-2" />
                    Special Launch Offer
                  </Badge>
                  
                  <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
                    Complete <span className="text-[#3ddc84]">Android App</span> Development
                  </h2>
                  
                  <p className="text-[#8b949e] mb-6 leading-relaxed">
                    From zero to published app — Java, Kotlin, Firebase, SQLite & more. 
                    45 hours of premium content.
                  </p>

                  <ul className="space-y-3 mb-8">
                    {[
                      '45 Hours • 250+ Lectures',
                      'Java, Kotlin, Firebase, SQLite',
                      '1.16 GB Downloadable Content',
                      'Lifetime Access + Certificate'
                    ].map((feature, i) => (
                      <li key={i} className="flex items-center gap-3 text-[#8b949e]">
                        <CheckCircle className="w-5 h-5 text-[#3ddc84]" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-baseline gap-4 mb-6">
                    <span className="text-4xl font-bold text-[#3ddc84]">₹199</span>
                    <span className="text-xl text-[#8b949e] line-through">₹995</span>
                    <span className="text-sm text-[#3ddc84] font-medium">Save ₹796 Today!</span>
                  </div>

                  <Button 
                    onClick={() => onAddToCart(androidCourse)}
                    disabled={isInCart(androidCourse.id) || isPurchased(androidCourse.id)}
                    size="lg"
                    className="bg-gradient-to-r from-[#3ddc84] to-[#2b9b5e] hover:opacity-90 text-[#0d1117] font-bold"
                  >
                    {isPurchased(androidCourse.id) ? (
                      <>
                        <CheckCircle className="w-5 h-5 mr-2" />
                        Already Owned
                      </>
                    ) : isInCart(androidCourse.id) ? (
                      <>
                        <CheckCircle className="w-5 h-5 mr-2" />
                        Added to Cart
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-5 h-5 mr-2" />
                        Grab at ₹199 Only
                      </>
                    )}
                  </Button>
                </div>

                <div className="flex items-center justify-center">
                  <div className="relative w-64 h-64">
                    <div className="absolute inset-0 bg-[#3ddc84]/10 rounded-full animate-pulse" />
                    <div className="absolute inset-4 bg-[#3ddc84]/5 rounded-full border border-[#3ddc84]/20 flex items-center justify-center">
                      <Smartphone className="w-32 h-32 text-[#3ddc84]" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Categories Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Browse Categories</h2>
            <p className="text-[#8b949e]">Explore courses by category</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categoriesData.map((cat) => {
              const Icon = categoryIcons[cat.id] || Code;
              return (
                <div
                  key={cat.id}
                  onClick={() => navigate(`/courses/${cat.id}`)}
                  className="group bg-[#161b22] border border-white/5 rounded-2xl p-6 cursor-pointer card-hover"
                >
                  <div 
                    className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                    style={{ 
                      background: `var(--${cat.color})20`,
                      color: `var(--${cat.color})`
                    }}
                  >
                    <Icon className="w-7 h-7" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-white mb-2">{cat.name}</h3>
                  <p className="text-[#8b949e] text-sm mb-4 line-clamp-2">{cat.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <span 
                      className="text-xs font-medium px-3 py-1 rounded-full"
                      style={{ 
                        background: `var(--${cat.color})10`,
                        color: `var(--${cat.color})`
                      }}
                    >
                      {cat.courseCount} Courses
                    </span>
                    <ArrowRight 
                      className="w-5 h-5 text-[#8b949e] group-hover:text-[#00c896] transition-colors" 
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Books Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Premium Books</h2>
            <p className="text-[#8b949e]">Expand your knowledge with our curated collection</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {bookCategories.map((cat) => (
              <div
                key={cat.id}
                onClick={() => navigate(`/books/${cat.id}`)}
                className="group bg-[#161b22] border border-white/5 rounded-2xl p-6 cursor-pointer card-hover"
              >
                <div 
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                  style={{ 
                    background: `var(--${cat.color})20`,
                    color: `var(--${cat.color})`
                  }}
                >
                  <BookOpen className="w-7 h-7" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-white mb-2">{cat.name}</h3>
                  <p className="text-[#8b949e] text-sm mb-4 line-clamp-2">{cat.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <span 
                      className="text-xs font-medium px-3 py-1 rounded-full"
                      style={{ 
                        background: `var(--${cat.color})10`,
                        color: `var(--${cat.color})`
                      }}
                    >
                      Browse Collection
                    </span>
                    <ArrowRight 
                      className="w-5 h-5 text-[#8b949e] group-hover:text-[#00c896] transition-colors" 
                    />
                  </div>
                </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">Featured Courses</h2>
              <p className="text-[#8b949e]">Most popular courses this week</p>
            </div>
            <Button 
              onClick={() => navigate('/courses')}
              variant="outline"
              className="border-white/10 text-white hover:bg-white/5 hidden sm:flex"
            >
              View All
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredCourses.map((course) => (
              <div 
                key={course.id}
                className="group bg-[#161b22] border border-white/5 rounded-2xl overflow-hidden card-hover"
              >
                <div 
                  className="h-40 flex items-center justify-center"
                  style={{
                    background: course.color === 'hacking' 
                      ? 'linear-gradient(135deg, #13111a 0%, #2d1b69 100%)'
                      : course.color === 'programming'
                      ? 'linear-gradient(135deg, #0d1117 0%, #0d3460 100%)'
                      : course.color === 'trading'
                      ? 'linear-gradient(135deg, #0d1a0d 0%, #0d3b1a 100%)'
                      : 'linear-gradient(135deg, #1a0d0d 0%, #3d1515 100%)'
                  }}
                >
                  <div 
                    className="w-16 h-16 rounded-xl flex items-center justify-center"
                    style={{ 
                      background: `var(--${course.color})20`,
                      border: `1px solid var(--${course.color})40`
                    }}
                  >
                    <span className="text-2xl">📚</span>
                  </div>
                </div>
                <div className="p-4">
                  <span 
                    className="text-[10px] font-bold uppercase tracking-wider"
                    style={{ color: `var(--${course.color})` }}
                  >
                    {course.category}
                  </span>
                  <h3 className="text-white font-semibold mt-1 mb-3 line-clamp-2 min-h-[48px]">
                    {course.title}
                  </h3>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-[#00c896]">₹{course.price.toLocaleString()}</span>
                    <Button 
                      onClick={() => onAddToCart(course)}
                      disabled={isInCart(course.id) || isPurchased(course.id)}
                      size="sm"
                      className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
                    >
                      {isPurchased(course.id) ? 'Owned' : isInCart(course.id) ? 'In Cart' : 'Add'}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Button 
              onClick={() => navigate('/courses')}
              variant="outline"
              className="border-white/10 text-white hover:bg-white/5"
            >
              View All Courses
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: CheckCircle, title: 'Lifetime Access', desc: 'Learn at your own pace' },
              { icon: Star, title: 'Expert Instructors', desc: 'Learn from industry pros' },
              { icon: Users, title: '10k+ Students', desc: 'Join our community' },
              { icon: Zap, title: 'Instant Delivery', desc: 'Get access immediately' },
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#00c896]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <item.icon className="w-6 h-6 text-[#00c896]" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">{item.title}</h4>
                  <p className="text-[#8b949e] text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
