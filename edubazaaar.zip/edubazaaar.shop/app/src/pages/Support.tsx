import { 
  MessageCircle, Mail, HelpCircle, Shield, 
  Clock, Phone, Send, Undo
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CONFIG } from '@/data';

export function Support() {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-white mb-4">Support Center</h1>
          <p className="text-[#8b949e]">We're here to help you 24/7</p>
        </div>

        {/* Support Cards */}
        <div className="grid sm:grid-cols-2 gap-6 mb-12">
          {/* WhatsApp Support */}
          <Card className="bg-[#161b22] border-white/5 hover:border-[#25D366]/30 transition-all group">
            <CardHeader className="pb-4">
              <div className="w-14 h-14 bg-[#25D366]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#25D366]/20 transition-colors">
                <MessageCircle className="w-7 h-7 text-[#25D366]" />
              </div>
              <CardTitle className="text-white text-xl">WhatsApp Support</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#8b949e] mb-6">
                Get instant help on WhatsApp. Available Mon–Sat, 9 AM – 9 PM IST
              </p>
              <a 
                href={`https://wa.me/${CONFIG.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat on WhatsApp
                </Button>
              </a>
            </CardContent>
          </Card>

          {/* Email Support */}
          <Card className="bg-[#161b22] border-white/5 hover:border-[#58a6ff]/30 transition-all group">
            <CardHeader className="pb-4">
              <div className="w-14 h-14 bg-[#58a6ff]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#58a6ff]/20 transition-colors">
                <Mail className="w-7 h-7 text-[#58a6ff]" />
              </div>
              <CardTitle className="text-white text-xl">Email Support</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#8b949e] mb-6">
                Send us your query and we'll get back within 24 hours.
              </p>
              <a 
                href={`mailto:${CONFIG.email}`}
                className="block"
              >
                <Button variant="outline" className="w-full border-white/10 text-white hover:bg-white/5">
                  <Mail className="w-4 h-4 mr-2" />
                  {CONFIG.email}
                </Button>
              </a>
            </CardContent>
          </Card>

          {/* FAQs */}
          <Card className="bg-[#161b22] border-white/5 hover:border-[#00c896]/30 transition-all group">
            <CardHeader className="pb-4">
              <div className="w-14 h-14 bg-[#00c896]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#00c896]/20 transition-colors">
                <HelpCircle className="w-7 h-7 text-[#00c896]" />
              </div>
              <CardTitle className="text-white text-xl">FAQs</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#8b949e] mb-6">
                Find answers to the most common questions about courses and payments.
              </p>
              <Button 
                variant="outline" 
                className="w-full border-white/10 text-white hover:bg-white/5"
                onClick={() => window.open('https://wa.me/' + CONFIG.whatsapp + '?text=I have a question', '_blank')}
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Ask a Question
              </Button>
            </CardContent>
          </Card>

          {/* Refund Guarantee */}
          <Card className="bg-[#161b22] border-white/5 hover:border-[#3fb950]/30 transition-all group">
            <CardHeader className="pb-4">
              <div className="w-14 h-14 bg-[#3fb950]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#3fb950]/20 transition-colors">
                <Shield className="w-7 h-7 text-[#3fb950]" />
              </div>
              <CardTitle className="text-white text-xl">7-Day Guarantee</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#8b949e] mb-6">
                Not satisfied? Get a full refund within 7 days, no questions asked.
              </p>
              <a 
                href={`https://wa.me/${CONFIG.whatsapp}?text=I want to request a refund`}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button className="w-full bg-[#3fb950] hover:bg-[#2ea043] text-white">
                  <Undo className="w-4 h-4 mr-2" />
                  Request Refund
                </Button>
              </a>
            </CardContent>
          </Card>
        </div>

        {/* Contact Info */}
        <div className="bg-[#161b22] border border-white/5 rounded-2xl p-8">
          <h2 className="text-xl font-bold text-white mb-6">Contact Information</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#25D366]/10 rounded-xl flex items-center justify-center">
                <Phone className="w-5 h-5 text-[#25D366]" />
              </div>
              <div>
                <p className="text-[#8b949e] text-sm">WhatsApp</p>
                <p className="text-white font-medium">+91 97591 31256</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#00c896]/10 rounded-xl flex items-center justify-center">
                <Mail className="w-5 h-5 text-[#00c896]" />
              </div>
              <div>
                <p className="text-[#8b949e] text-sm">Email</p>
                <p className="text-white font-medium">{CONFIG.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#58a6ff]/10 rounded-xl flex items-center justify-center">
                <Clock className="w-5 h-5 text-[#58a6ff]" />
              </div>
              <div>
                <p className="text-[#8b949e] text-sm">Working Hours</p>
                <p className="text-white font-medium">Mon–Sat, 9 AM – 9 PM</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Help */}
        <div className="mt-12 text-center">
          <h3 className="text-lg font-semibold text-white mb-4">Need quick help?</h3>
          <p className="text-[#8b949e] mb-6">
            Our AI assistant is available 24/7 to answer your questions
          </p>
          <div className="flex justify-center gap-4">
            <Button 
              onClick={() => window.dispatchEvent(new CustomEvent('openChat'))}
              className="bg-[#00c896] hover:bg-[#00a97e] text-[#0d1117]"
            >
              <Send className="w-4 h-4 mr-2" />
              Chat with AI Assistant
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
